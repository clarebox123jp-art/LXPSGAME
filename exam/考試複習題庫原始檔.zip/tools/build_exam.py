#!/usr/bin/env python3
"""把 units/*.json 組成遊戲用的題庫檔:
   out/exam/exam_index.js   (目錄:各冊檔名、各版本單元名稱與題數)
   out/exam/q_<冊碼>.js     (每冊一檔,壓縮陣列)
題目 id = 版本碼+冊碼+單元 + '-' + 題幹雜湊(穩定:審題改順序/換題不影響其他題的已答對紀錄)。
用法: python3 build_exam.py [版本日期YYYYMMDD]
"""
import json, glob, os, sys, hashlib, re, collections

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out', 'exam')
VER = sys.argv[1] if len(sys.argv) > 1 else '20261022'
PUB = {'N': '南一', 'H': '翰林', 'K': '康軒'}
GRADE = {'3': '三', '4': '四', '5': '五', '6': '六'}
TERM = {'A': '上', 'B': '下'}
SUBJ = {'S': '自然', 'O': '社會'}
DIFF = {'沒自信': 1, '普通': 2, '我很會': 3}


def book_name(code):  # '6AS' -> 六上自然
    return GRADE[code[0]] + TERM[code[1]] + SUBJ[code[2]]


def qhash(s):
    return hashlib.md5(re.sub(r'\s', '', s).encode('utf-8')).hexdigest()[:6]


def main():
    os.makedirs(OUT, exist_ok=True)
    books = collections.OrderedDict()
    stats = []
    for f in sorted(glob.glob(os.path.join(HERE, 'units', '*_U*.json'))):
        m = re.match(r'([NHK])_(\d[AB][SO])_U(\d+)\.json$', os.path.basename(f))
        if not m:
            continue
        pc, bc, u = m.group(1), m.group(2), int(m.group(3))
        d = json.load(open(f, encoding='utf-8'))
        bn = book_name(bc)
        assert d.get('book') == bn, (f, d.get('book'))
        assert d.get('pub') == PUB[pc], (f, d.get('pub'))
        bk = books.setdefault(bn, {'code': bc.lower(), 'units': {}, 'rows': []})
        seen = set()
        n = 0
        for q in d['q']:
            h = qhash(q['q'])
            while h in seen:
                h = hashlib.md5((h + 'x').encode()).hexdigest()[:6]
            seen.add(h)
            qid = '%s%s%d-%s' % (pc, bc, u, h)
            o = q['o']
            assert len(o) == 4 and 0 <= q['a'] <= 3, (f, q['q'])
            row = [qid, pc, u, q.get('act', ''), DIFF.get(q.get('d'), 2), q['q'], o[0], o[1], o[2], o[3], q['a'], q.get('why', '')]
            if q.get('pic'):
                row.append(q['pic'])
            bk['rows'].append(row)
            n += 1
        bk['units'].setdefault(pc, []).append({'u': u, 't': d.get('utitle', ''), 'n': n})
        stats.append((bn, PUB[pc], u, d.get('utitle', ''), n))
    index = {'v': VER, 'books': {}}
    for bn, bk in books.items():
        fn = 'q_%s.js' % bk['code']
        for pc in bk['units']:
            bk['units'][pc].sort(key=lambda x: x['u'])
        index['books'][bn] = {'file': fn, 'v': VER, 'units': bk['units'], 'n': len(bk['rows'])}
        body = json.dumps(bk['rows'], ensure_ascii=False, separators=(',', ':'))
        with open(os.path.join(OUT, fn), 'w', encoding='utf-8') as w:
            w.write('/* 考試複習題庫 %s v%s — 由 build_exam.py 自動產生,請勿手改 */\n' % (bn, VER))
            w.write('window.EXAM_Q=window.EXAM_Q||{};window.EXAM_Q[%s]=%s;\n' % (json.dumps(bn, ensure_ascii=False), body))
    with open(os.path.join(OUT, 'exam_index.js'), 'w', encoding='utf-8') as w:
        w.write('/* 考試複習題庫目錄 v%s — 由 build_exam.py 自動產生,請勿手改 */\n' % VER)
        w.write('window.EXAM_INDEX=%s;\n' % json.dumps(index, ensure_ascii=False, separators=(',', ':')))
    import shutil
    shutil.copy(os.path.join(HERE, 'exam_core.js'), os.path.join(OUT, 'exam_core.js'))
    tot = sum(s[4] for s in stats)
    print('單元數', len(stats), '總題數', tot)
    for s in stats:
        flag = '' if s[4] >= 100 else '  ⚠ 不足100'
        print('  %s %s 第%d單元 %s：%d 題%s' % (s[0], s[1], s[2], s[3], s[4], flag))
    for fn in sorted(os.listdir(OUT)):
        print('  ', fn, os.path.getsize(os.path.join(OUT, fn)) // 1024, 'KB')


if __name__ == '__main__':
    main()
