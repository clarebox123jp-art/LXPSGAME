#!/usr/bin/env python3
"""檢查單一單元題庫 JSON 是否符合 SPEC.md。用法: python3 check_unit.py file.json [--min 100]"""
import json, sys, re, collections

BAD_OPT = re.compile(r'^(以上皆是|以上皆非|以上都對|以上都不對|以上皆對|都對|都不對|以上都是|以上都非)')
DIFFS = {'沒自信', '普通', '我很會'}


def norm(s):
    return re.sub(r'[\s，。、？！「」『』：；（）()?,.!]', '', s)


def check(path, need=100):
    errs, warns = [], []
    try:
        d = json.load(open(path, encoding='utf-8'))
    except Exception as e:
        return [f'JSON 解析失敗: {e}'], []
    for k in ('pub', 'book', 'unit', 'utitle', 'q'):
        if k not in d:
            errs.append(f'缺少欄位 {k}')
    qs = d.get('q', [])
    if len(qs) < need:
        errs.append(f'題數 {len(qs)} < {need}')
    seen = {}
    pos = collections.Counter()
    dif = collections.Counter()
    neg = 0
    for i, q in enumerate(qs, 1):
        tag = f'第{i}題'
        for k in ('act', 'd', 'q', 'o', 'a', 'why'):
            if k not in q:
                errs.append(f'{tag} 缺 {k}')
        o = q.get('o', [])
        if not isinstance(o, list) or len(o) != 4:
            errs.append(f'{tag} 選項數不是 4')
        else:
            if len(set(norm(x) for x in o)) != 4:
                errs.append(f'{tag} 選項重複')
            for x in o:
                if not isinstance(x, str) or not x.strip():
                    errs.append(f'{tag} 空白選項')
                elif BAD_OPT.match(x.strip()):
                    errs.append(f'{tag} 不可用「{x}」')
        a = q.get('a')
        if not isinstance(a, int) or not 0 <= a <= 3:
            errs.append(f'{tag} a 不在 0~3')
        else:
            pos[a] += 1
        if q.get('d') not in DIFFS:
            errs.append(f'{tag} 難度 {q.get("d")} 不合法')
        else:
            dif[q['d']] += 1
        if not str(q.get('why', '')).strip():
            errs.append(f'{tag} why 空白')
        t = str(q.get('q', ''))
        if re.search(r'如圖|下圖|上圖|附圖', t):
            errs.append(f'{tag} 題幹依賴圖片')
        if re.search(r'不正確|不是|錯誤|不屬於|不可以|不能|不會|不適合|不需要', t):
            neg += 1
        n = norm(t)
        if n in seen:
            errs.append(f'{tag} 題幹與第{seen[n]}題重複')
        else:
            seen[n] = i
    tot = max(1, len(qs))
    for k in range(4):
        r = pos[k] / tot
        if r < 0.15 or r > 0.35:
            warns.append(f'答案位置 {k} 佔 {r:.0%}(建議約 25%)')
    if neg / tot > 0.2:
        warns.append(f'否定題 {neg/tot:.0%} 偏多')
    return errs, warns + [f'題數 {len(qs)}；難度 {dict(dif)}；答案位置 {dict(sorted(pos.items()))}']


if __name__ == '__main__':
    need = 100
    args = sys.argv[1:]
    if '--min' in args:
        need = int(args[args.index('--min') + 1])
    files = [a for a in args if a.endswith('.json')]
    bad = 0
    for f in files:
        e, w = check(f, need)
        print(('❌ ' if e else '✅ ') + f)
        for x in e[:40]:
            print('   錯誤:', x)
        if len(e) > 40:
            print(f'   …另有 {len(e)-40} 個錯誤')
        for x in w:
            print('   提醒:', x)
        bad += bool(e)
    sys.exit(1 if bad else 0)
